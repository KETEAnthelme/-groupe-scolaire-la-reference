# GROUPE SCOLAIRE LA REFERENCE — version serveur
## Lancement local
1. Installer Python 3.11+.
2. `pip install -r requirements.txt`
3. `python app.py`
4. Ouvrir `http://127.0.0.1:5000`
Compte initial: admin / admin123 (à changer immédiatement).
Cette version utilise SQLite et constitue une base fonctionnelle. Pour une mise en production Internet, utiliser HTTPS, PostgreSQL, sauvegardes automatiques, gestion complète des rôles, stockage sécurisé et un fournisseur officiel de notifications.
