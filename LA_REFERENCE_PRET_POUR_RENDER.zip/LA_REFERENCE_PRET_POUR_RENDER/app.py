import os, sqlite3, csv, io
from flask import Flask, render_template, request, redirect, session, flash, Response
from werkzeug.security import generate_password_hash, check_password_hash
app=Flask(__name__); app.secret_key=os.environ.get('SECRET_KEY','change-me'); DB=os.environ.get('DATABASE_PATH','la_reference.db')
def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 c=db(); c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT);CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY,matricule TEXT UNIQUE,nom TEXT,prenom TEXT,classe TEXT,sexe TEXT,parent TEXT,telephone TEXT);CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY,identifiant TEXT UNIQUE,nom TEXT,matiere TEXT,classes TEXT);CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY,student_id INTEGER,trimestre TEXT,matiere TEXT,note REAL,coefficient REAL);CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,student_id INTEGER,libelle TEXT,montant_du REAL,montant_paye REAL);CREATE TABLE IF NOT EXISTS absences(id INTEGER PRIMARY KEY,student_id INTEGER,date TEXT,type TEXT,justifiee INTEGER DEFAULT 0);""")
 if not c.execute("SELECT 1 FROM users WHERE username='admin'").fetchone(): c.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",('admin',generate_password_hash('admin123'),'direction'))
 c.commit(); c.close()
init()
def auth(): return 'user' in session
@app.route('/',methods=['GET','POST'])
def login():
 if request.method=='POST':
  c=db(); u=c.execute('SELECT * FROM users WHERE username=?',(request.form['username'],)).fetchone(); c.close()
  if u and check_password_hash(u['password'],request.form['password']): session['user']=u['username']; return redirect('/dashboard')
  flash('Identifiants incorrects.')
 return render_template('login.html') if not auth() else redirect('/dashboard')
@app.route('/logout')
def logout(): session.clear(); return redirect('/')
@app.route('/dashboard')
def dashboard():
 if not auth(): return redirect('/')
 c=db(); e=c.execute('SELECT COUNT(*) n FROM students').fetchone()['n']; p=c.execute('SELECT COUNT(*) n FROM teachers').fetchone()['n']; i=c.execute('SELECT COUNT(*) n FROM payments WHERE montant_du>montant_paye').fetchone()['n']; c.close(); return render_template('dashboard.html',eleves=e,profs=p,impayes=i)
@app.route('/eleves',methods=['GET','POST'])
def eleves():
 if not auth(): return redirect('/')
 c=db()
 if request.method=='POST':
  try: c.execute('INSERT INTO students(matricule,nom,prenom,classe,sexe,parent,telephone) VALUES(?,?,?,?,?,?,?)',[request.form[k] for k in ('matricule','nom','prenom','classe','sexe','parent','telephone')]); c.commit(); flash('Élève enregistré.')
  except sqlite3.IntegrityError: flash('Matricule déjà utilisé.')
 q=request.args.get('q',''); rows=c.execute('SELECT * FROM students WHERE nom LIKE ? OR prenom LIKE ? OR matricule LIKE ? ORDER BY nom',(f'%{q}%',f'%{q}%',f'%{q}%')).fetchall(); c.close(); return render_template('eleves.html',rows=rows,q=q)
@app.route('/import',methods=['GET','POST'])
def importer():
 if not auth(): return redirect('/')
 if request.method=='POST':
  f=request.files.get('file')
  if f:
   c=db(); n=0
   for r in csv.DictReader(io.StringIO(f.read().decode('utf-8-sig'))):
    if r.get('matricule'): c.execute('INSERT OR IGNORE INTO students(matricule,nom,prenom,classe,sexe,parent,telephone) VALUES(?,?,?,?,?,?,?)',(r.get('matricule'),r.get('nom',''),r.get('prenom',''),r.get('classe',''),r.get('sexe',''),r.get('parent',''),r.get('telephone',''))); n+=1
   c.commit(); c.close(); flash(f'{n} ligne(s) traitée(s).')
 return render_template('import.html')
@app.route('/impayes')
def impayes():
 if not auth(): return redirect('/')
 c=db(); rows=c.execute('SELECT s.matricule,s.nom,s.prenom,s.classe,p.libelle,p.montant_du,p.montant_paye,(p.montant_du-p.montant_paye) reste FROM payments p JOIN students s ON s.id=p.student_id WHERE p.montant_du>p.montant_paye ORDER BY s.classe,s.nom').fetchall(); c.close(); return render_template('impayes.html',rows=rows)
@app.route('/export/eleves.csv')
def export():
 if not auth(): return redirect('/')
 c=db(); rows=c.execute('SELECT matricule,nom,prenom,classe,sexe,parent,telephone FROM students ORDER BY nom').fetchall(); c.close(); o=io.StringIO(); w=csv.writer(o); w.writerow(['matricule','nom','prenom','classe','sexe','parent','telephone']); [w.writerow(list(r)) for r in rows]; return Response(o.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=eleves.csv'})
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)))
